# 🛍 MarketEdge Retail Analytics
Delivering Data-Driven Insights for Smarter Retail Strategy and Inventory Management.

### 🔍 About
MarketEdge Retail Analytics integrates SQL, Python, dbt, and Tableau for unified profitability and performance insights.

### ⚙️ Tech Stack
- Python
- Snowflake
- dbt
- Tableau
- Pandas / NumPy

### 📊 Key Features
- Profitability Analysis by Store
- Customer Segmentation
- Automated ETL and dbt Pipeline
- Tableau Dashboard Integration

### 🔗 Quick Links
- [📓 Analysis Notebook](notebooks/MarketEdge_Analysis.ipynb)
- [📈 Visualization](visuals/store_profitability_chart.png)
- [📁 Data Folder](data/)
